self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5484e2f3b16a11d86f7c0a479bbd194b",
    "url": "/index.html"
  },
  {
    "revision": "d37f55c532262eaf416d",
    "url": "/static/css/main.d2a9886e.chunk.css"
  },
  {
    "revision": "8f9f9f703c671000de7b",
    "url": "/static/js/2.3e91e924.chunk.js"
  },
  {
    "revision": "d37f55c532262eaf416d",
    "url": "/static/js/main.6a0c9971.chunk.js"
  },
  {
    "revision": "d0a01327a639b374b49a",
    "url": "/static/js/runtime~main.191b7bc3.js"
  },
  {
    "revision": "eb219d0defd6f4f9f6fbb16bace29123",
    "url": "/static/media/LOGO.eb219d0d.png"
  },
  {
    "revision": "a4f2cb80ff2ae2772e80bf30e9d78d4c",
    "url": "/static/media/loading.a4f2cb80.gif"
  },
  {
    "revision": "9d378898517e631cb3c02db6e3920a2c",
    "url": "/static/media/wallpaper.9d378898.jpg"
  }
]);